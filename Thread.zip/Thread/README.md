Key TEMP
about Key Temp.

** Key Temp is a control heating System, made to optimize and make accurate controlling of building heating systems
using Wi-Fi while having it personalized for the user with both auto and manual controlling.

this website hosts the UX/UI for the user!
========
how to start:
1- Download the repo.
2- copy the full path of the index.html
3- paste it to your browser
3- run the website!
